# Klaverjas

The Dutch card game klaverjas for two: you against the computer. iPhone, iPad
and Mac, from one SwiftUI codebase.

The game logic is not new. It was written in Borland C in 1994, ported to C# in
2025, and to Swift in 2026 — line by line each time. It plays the same tactics
it did thirty years ago, and there is a test that proves it.

The cards are the original pixel drawings from `KJKRT.C`, drawn by hand, one
character per pixel.

## Building

Open `Klaverjas/Klaverjas.xcodeproj` in Xcode and run. You will need to set your
own development team under Signing & Capabilities — the field is deliberately
empty.

The game itself needs no Xcode:

```bash
cd KlaverjasSwift
swift test -c release        # 17 tests, about 15 seconds
swift run -c release spoor 200 1 spoor.txt
```

Requires macOS 14 / iOS 17 or newer.

## How the port was kept honest

Two reference files, both produced by the previous version, decide whether the
port is faithful:

**`spoor-csharp.txt`** — 200 deals played by the C# engine at seed 1, one line
per card played, 6601 lines. The Swift engine has to produce that file exactly.
The random generator is four lines of arithmetic that gives identical numbers in
any language, so the same seed deals the same cards. If a single tactic differs,
the first mismatching line names the deal, the trick and the card.

**`kaarten.png`** — all 32 cards plus the back, rendered by the C# version at
triple size. The Swift renderer is compared against it pixel for pixel.

Both run as ordinary tests. Neither is decoration: switching one constant in the
trick-chance calculation makes the trace diverge at deal 83, trick 6.

## Layout

| | |
|---|---|
| `KlaverjasSwift/Sources/KlaverjasKit` | the engine — dealing, chances, meld, rules, tactics |
| `KlaverjasSwift/Sources/KlaverjasKaarten` | the cards, built pixel by pixel, no drawing framework |
| `KlaverjasSwift/Sources/KlaverjasApp` | the SwiftUI screens, wide and narrow |
| `KlaverjasSwift/Sources/*` (tools) | trace writer, contact sheet, icon, screenshots, preview film |
| `Klaverjas/` | the Xcode project that turns it into an app |
| `KJ.C`, `KJJ.C`, `KJKRT.C`, `KRTDANS.C` | the 1994 original, unchanged |
| `genkaarten.py` | reads the card drawings out of `KJKRT.C` and writes Swift |

The engine imports no UI framework at all, which is what made it portable in the
first place — and the package manifest keeps it that way.

## Notes for anyone reading the code

The comments and the deeper documents are in Dutch, as are the identifiers: this
started as a Dutch program about a Dutch game and stayed that way.

`TACTIEKEN.md` lists all 67 tactic numbers and what the computer does at each —
those numbers come straight from the 1994 source and are visible in the app's
statistics screen.

`LEESMIJ-CSharp.md` documents the earlier C-to-C# port, including six places
where the original read past the end of an array or used an uninitialised
variable. Those quirks were kept rather than fixed: repairing them would change
how the computer plays, and the whole point was that it should not.

## Licence

Apache License 2.0 — see `LICENSE`. You may use, change and redistribute this,
including in commercial work, provided you keep the copyright notice and state
what you changed. It comes with no warranty.

Copyright 2026 Ed Nieuwenhuys. The game logic and the card drawings date from
1994 and are by the same author.
