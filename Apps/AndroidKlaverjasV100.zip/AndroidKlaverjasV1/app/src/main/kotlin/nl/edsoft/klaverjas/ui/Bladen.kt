package nl.edsoft.klaverjas.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.systemBarsPadding
import nl.edsoft.klaverjas.SpelView
import nl.edsoft.klaverjas.kaarten.OrigineleKaarten
import kotlin.math.roundToInt
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import nl.edsoft.klaverjas.Handleiding
import nl.edsoft.klaverjas.Statistiek
import nl.edsoft.klaverjas.Taal
import nl.edsoft.klaverjas.tactiekNaam

/** De bladen die over het speelscherm heen komen: opties, statistiek en spelregels. */
enum class Blad { OPTIES, STATISTIEK, SPELREGELS }

/** Gemeenschappelijke vorm: donkere ondergrond, titel, rollende inhoud, en onderaan een rij knoppen. */
@Composable
private fun BladKader(titel: String, onderrij: @Composable RowScope.() -> Unit, inhoud: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Kleuren.paneel)
            .systemBarsPadding()
            .padding(18.dp),
    ) {
        Text(titel, color = Kleuren.geel, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) { inhoud() }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { onderrij() }
    }
}

@Composable
private fun TekstKnop(tekst: String, klik: () -> Unit) {
    Text(
        tekst, color = Kleuren.geel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clickable(onClick = klik).padding(horizontal = 10.dp, vertical = 10.dp),
    )
}

@Composable
private fun Scheiding() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Kleuren.geel.copy(alpha = 0.3f)))
}

// ---------------------------------------------------------------- opties

@Composable
fun OptieBlad(model: SpelModel, sluit: () -> Unit, toonSpelregels: () -> Unit) {
    BladKader(
        Taal.menuOpties,
        onderrij = {
            TekstKnop(Taal.menuSpelregels, toonSpelregels)
            Spacer(Modifier.weight(1f))
            TekstKnop(Taal.statSluiten, sluit)
        },
    ) {
        Schakelaar(Taal.menuDemo, model.demo) { model.zetDemo(it) }
        Schakelaar(Taal.menuOpenKaart, model.openKaart) { model.zetOpenKaart(it) }
        Schakelaar(Taal.menuAuto, model.automatisch) { model.zetAutomatisch(it) }
        Schakelaar(Taal.menuSnel, model.snel) { model.zetSnel(it); if (it) sluit() }

        Spacer(Modifier.height(10.dp))
        Scheiding()
        Spacer(Modifier.height(12.dp))

        Text(Taal.menuSpeelwijze, color = Kleuren.geel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        SpeelwijzeKeuze(Taal.menuNoordSpeelt, model.stijlNoord) { model.zetStijlNoord(it) }
        // Zuid alleen als de computer die kant speelt; anders speel je zelf.
        if (model.demo) {
            Spacer(Modifier.height(10.dp))
            SpeelwijzeKeuze(Taal.menuZuidSpeelt, model.stijlZuid) { model.zetStijlZuid(it) }
        }

        Spacer(Modifier.height(14.dp))
        Scheiding()
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(Taal.menuTaal, color = Kleuren.geel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Row(Modifier.border(1.dp, Kleuren.geel.copy(alpha = 0.45f))) {
                TaalKnop("NL", !model.engels) { model.zetEngels(false) }
                TaalKnop("EN", model.engels) { model.zetEngels(true) }
            }
        }

        VorigeSlagRij(model.view)

        Spacer(Modifier.height(24.dp))
        Text(
            Taal.menuVersie(model.versie), color = Kleuren.geel.copy(alpha = 0.5f), fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun Schakelaar(tekst: String, aan: Boolean, wijzig: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { wijzig(!aan) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(tekst, color = Kleuren.geel, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = aan, onCheckedChange = wijzig,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Kleuren.paneel, checkedTrackColor = Kleuren.geel,
                uncheckedThumbColor = Kleuren.geel, uncheckedTrackColor = Kleuren.achtergrond,
                uncheckedBorderColor = Kleuren.geel.copy(alpha = 0.5f),
            ),
        )
    }
}

@Composable
private fun TaalKnop(naam: String, gekozen: Boolean, klik: () -> Unit) {
    Box(
        Modifier
            .width(54.dp).height(32.dp)
            .background(if (gekozen) Kleuren.geel.copy(alpha = 0.85f) else Color.Transparent)
            .clickable(onClick = klik),
        contentAlignment = Alignment.Center,
    ) {
        Text(naam, color = if (gekozen) Kleuren.paneel else Kleuren.geel, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** De speelwijze van één kant: de vuistregels van Ednieuw, het doorrekenen van Ronlog of het uitspelen van Claude. */
@Composable
private fun SpeelwijzeKeuze(kop: String, gekozen: Int, kies: (Int) -> Unit) {
    Text(kop, color = Kleuren.geel.copy(alpha = 0.8f), fontSize = 13.sp)
    Spacer(Modifier.height(4.dp))
    Column(Modifier.fillMaxWidth().border(1.dp, Kleuren.geel.copy(alpha = 0.45f))) {
        SpeelwijzeRij(Taal.menuAiEd, gekozen == 0) { kies(0) }
        SpeelwijzeRij(Taal.menuAiLoggen, gekozen == 1) { kies(1) }
        SpeelwijzeRij(Taal.menuAiClaude, gekozen == 2) { kies(2) }
    }
}

@Composable
private fun SpeelwijzeRij(naam: String, gekozen: Boolean, klik: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth().height(40.dp)
            .background(if (gekozen) Kleuren.geel.copy(alpha = 0.85f) else Color.Transparent)
            .clickable(onClick = klik)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            naam, color = if (gekozen) Kleuren.paneel else Kleuren.geel, fontSize = 14.sp,
            fontWeight = if (gekozen) FontWeight.Bold else FontWeight.Normal, maxLines = 1,
        )
    }
}

// ------------------------------------------------------------ statistiek

/** De tellingen die het origineel bij het afsluiten afdrukte, met Zuid en Noord als kolommen. */
@Composable
fun StatistiekBlad(stat: Statistiek, wis: () -> Unit, sluit: () -> Unit) {
    var vraagtOmWissen by remember { mutableStateOf(false) }
    BladKader(
        Taal.statTitel,
        onderrij = {
            // Wissen kan niet ongedaan gemaakt worden, dus er hoort een vraag tussen. Links, ver van Sluiten.
            if (!stat.leeg) {
                if (vraagtOmWissen) {
                    Text(Taal.statWissenZeker, color = Kleuren.geel.copy(alpha = 0.85f), fontSize = 13.sp)
                    TekstKnop(Taal.statWissenJa) { vraagtOmWissen = false; wis(); sluit() }
                    TekstKnop(Taal.statWissenNee) { vraagtOmWissen = false }
                } else {
                    TekstKnop(Taal.statWissen) { vraagtOmWissen = true }
                }
            }
            Spacer(Modifier.weight(1f))
            TekstKnop(Taal.statSluiten, sluit)
        },
    ) {
        if (stat.leeg) {
            Text(Taal.statNogNiets, color = Kleuren.geel.copy(alpha = 0.8f), modifier = Modifier.padding(vertical = 20.dp))
        } else {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                Kolom(Taal.zuid, true); Kolom(Taal.noord, true)
            }
            Scheiding()
            Regel(Taal.statStand, stat.totaal)
            Regel(Taal.statPartijen, stat.partijen)
            Regel(Taal.statSpellen, stat.spellen)
            Regel(Taal.statKaartpunten, stat.kaartpunten)
            Regel(Taal.statTroefpunten, stat.troefpunten)
            Regel(Taal.statTroefkaarten, stat.troefkaarten)
            Regel(Taal.statRoempunten, stat.roempunten)
            Regel(Taal.statPit, stat.pit)
            Regel(Taal.statTegenpit, stat.tegenpit)
            Regel(Taal.statNat, stat.nat)
            Scheiding()
            Regel(Taal.statSuperroem, stat.superroem)

            if (stat.gebruikteTactieken.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Scheiding()
                Spacer(Modifier.height(16.dp))
                Text(Taal.statTactiek, color = Kleuren.geel, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(Taal.statTactiekUitleg, color = Kleuren.geel.copy(alpha = 0.65f), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                for ((nr, aantal) in stat.gebruikteTactieken) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(26.dp).height(17.dp).background(Kleuren.geel.copy(alpha = 0.85f)), contentAlignment = Alignment.Center) {
                            Text("$nr", color = Kleuren.paneel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(8.dp))
                        // 70 is niet van 1994 maar van de zoekende speler.
                        Text(
                            when (nr) { 70 -> Taal.statTactiekZoeken; 71 -> Taal.statTactiekClaude; else -> Taal.tactiekNaam(nr) },
                            color = Kleuren.geel.copy(alpha = 0.9f), fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f),
                        )
                        Text("$aantal", color = Kleuren.geel, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun Kolom(tekst: String, kop: Boolean) {
    Text(
        tekst, color = Kleuren.geel.copy(alpha = if (kop) 0.7f else 1f), fontSize = if (kop) 12.sp else 13.sp,
        fontWeight = if (kop) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.width(76.dp).padding(vertical = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End,
    )
}

@Composable
private fun Regel(kop: String, paar: LongArray) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(kop, color = Kleuren.geel, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(vertical = 4.dp))
        Kolom("${paar[0]}", false); Kolom("${paar[1]}", false)
    }
}

// ----------------------------------------------------------- spelregels

@Composable
fun HandleidingBlad(sluit: () -> Unit) {
    BladKader(
        Taal.menuSpelregels,
        onderrij = { Spacer(Modifier.weight(1f)); TekstKnop(Taal.statSluiten, sluit) },
    ) {
        for (stuk in Handleiding.stukken()) {
            Text(stuk.kop, color = Kleuren.geel, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(stuk.tekst, color = Kleuren.geel.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ------------------------------------------------------------ vorige slag

/** De kaarten van de vorige slag, zodat je nog even kunt nakijken wat er viel. Op een telefoon is er geen paneel, dus staat hij hier. */
@Composable
private fun VorigeSlagRij(view: SpelView) {
    if (view.vorigeSlag.isEmpty()) return
    val density = LocalDensity.current.density
    // Hele vergroting, zodat elke kaartpixel precies op schermpixels valt.
    val k = maxOf(1, density.roundToInt())
    val beelden = remember(k) { Kaartbeelden(k) }
    Spacer(Modifier.height(14.dp))
    Scheiding()
    Spacer(Modifier.height(12.dp))
    Text(Taal.vorigeSlag, color = Kleuren.geel.copy(alpha = 0.8f), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
    val breed = with(LocalDensity.current) { (OrigineleKaarten.BREEDTE * k).toDp() }
    val hoog = with(LocalDensity.current) { (OrigineleKaarten.HOOGTE * k).toDp() }
    Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
        for (kaart in view.vorigeSlag) {
            val b = beelden.voor(kaart.naam, kaart.kleur) ?: continue
            Image(b, contentDescription = null, filterQuality = FilterQuality.None, modifier = Modifier.size(breed, hoog))
        }
    }
}

// ------------------------------------------------------- partij en snel spelen

/** Het grote scherm bij het einde van een partij (1500 punten). Dekt het hele speelveld af; een tik gaat verder. */
@Composable
fun PartijSplash(view: SpelView, tik: () -> Unit) {
    val kop = when {
        view.partijGelijkspel -> Taal.partijGelijk
        view.partijGewonnenDoorMij -> Taal.partijGewonnen
        else -> Taal.partijVerloren
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Kleuren.achtergrond.copy(alpha = 0.98f))
            .systemBarsPadding()
            .clickable(onClick = tik)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (!view.partijGelijkspel) {
            Text(if (view.partijGewonnenDoorMij) "\uD83C\uDFC6" else "\uD83C\uDFC1", fontSize = 64.sp)
            Spacer(Modifier.height(16.dp))
        }
        Text(kop, color = Kleuren.geel, fontSize = 32.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(Taal.partijStand(view.mijnPartijen, view.zijnPartijen), color = Color(245, 245, 240), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Text(view.melding, color = Color(245, 245, 240).copy(alpha = 0.75f), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 30.dp))
        Spacer(Modifier.height(26.dp))
        Text(Taal.tikVerder, color = Kleuren.geel.copy(alpha = 0.85f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** Snel spelen zonder kaarten: een teller, een knop voor de oplopende statistiek en een knop om te stoppen. */
@Composable
fun SnelScherm(model: SpelModel, toonStatistiek: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Kleuren.achtergrond)
            .systemBarsPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(Taal.snelBezig, color = Kleuren.geel, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Text(Taal.snelSpellen(model.snelGespeeld), color = Color(245, 245, 240), fontSize = 17.sp)
        Spacer(Modifier.height(30.dp))
        // De statistiek loopt vanzelf mee: het scherm wordt een paar keer per seconde ververst.
        Box(
            Modifier
                .border(1.dp, Kleuren.geel.copy(alpha = 0.6f))
                .clickable(onClick = toonStatistiek)
                .padding(horizontal = 36.dp, vertical = 12.dp),
        ) {
            Text(Taal.menuStatistieken, color = Kleuren.geel, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .background(Kleuren.geel.copy(alpha = 0.85f))
                .clickable { model.zetSnel(false) }
                .padding(horizontal = 36.dp, vertical = 12.dp),
        ) {
            Text(Taal.snelUitzetten, color = Kleuren.paneel, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
