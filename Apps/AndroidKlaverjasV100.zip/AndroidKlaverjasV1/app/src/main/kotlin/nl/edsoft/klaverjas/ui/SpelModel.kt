package nl.edsoft.klaverjas.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.core.os.ConfigurationCompat
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import nl.edsoft.klaverjas.Instellingen
import nl.edsoft.klaverjas.KaartView
import nl.edsoft.klaverjas.KjSpel
import nl.edsoft.klaverjas.KjUi
import nl.edsoft.klaverjas.SpelView
import nl.edsoft.klaverjas.Taal
import nl.edsoft.klaverjas.Teken

/** Waar de speelloop op wacht. */
enum class Modus { GEEN, KIES_KAART, KIES_TROEF, VERDER }

/**
 * Houdt de speelloop (een [KjSpel] in een coroutine) en de toestand voor het scherm. De
 * loop draait buiten de hoofdthread; het scherm leest alleen [view], [modus] en [tekst]
 * en geeft zijn tikken door via [klik], [kiesTroef] en [gaVerder].
 */
class SpelModel(app: Application) : AndroidViewModel(app) {
    private val bewaarplaats = Bewaarplaats(app)

    /** Versienaam uit het manifest, voor onderaan het optieblad. */
    val versie: String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    var view by mutableStateOf(SpelView())
        private set
    var modus by mutableStateOf(Modus.GEEN)
        private set
    var tekst by mutableStateOf("")
        private set

    var demo by mutableStateOf(false)
        private set
    var openKaart by mutableStateOf(false)
        private set
    /** Speelwijze van Noord: 0 = Ednieuw (vuistregels), 1 = Ronlog (rekent een slag door), 2 = Claude (speelt het spel uit). */
    var stijlNoord by mutableStateOf(0)
        private set
    /** Speelwijze van Zuid; alleen van belang in demo. Standaard Ronlog, zodat een demo twee speelwijzen tegen elkaar zet. */
    var stijlZuid by mutableStateOf(1)
        private set
    var automatisch by mutableStateOf(false)
        private set
    var engels by mutableStateOf(false)
        private set

    /** Snel spelen zonder kaarten: de computer speelt beide kanten, er wordt niet gewacht. */
    var snel by mutableStateOf(false)
        private set
    /** Hoeveel spellen er in totaal zijn gespeeld, bijgewerkt tijdens snel spelen. */
    var snelGespeeld by mutableStateOf(0L)
        private set
    private var laatstGetekend = 0L

    @Volatile private var instellingen = Instellingen()
    private var job: Job? = null

    private var kaartWacht: CompletableDeferred<Pair<Teken, Int>>? = null
    private var troefWacht: CompletableDeferred<Int>? = null
    private var verderWacht: CompletableDeferred<Unit>? = null

    private val ui = object : KjUi {
        override val snelSpelen: Boolean get() = snel

        override suspend fun toon(view: SpelView) {
            // Snel spelen: geen kaart tekenen en niet wachten.
            if (snel) return
            this@SpelModel.view = view
            // Even de tijd om te zien welke kaart er viel.
            delay(if (instellingen.demo) 150 else 450)
        }

        override suspend fun kiesKaart(view: SpelView): Pair<Teken, Int> {
            val wacht = CompletableDeferred<Pair<Teken, Int>>()
            kaartWacht = wacht
            this@SpelModel.view = view
            tekst = view.melding.ifEmpty { view.status }
            modus = Modus.KIES_KAART
            return wacht.await()
        }

        override suspend fun kiesTroef(view: SpelView): Int {
            val wacht = CompletableDeferred<Int>()
            troefWacht = wacht
            this@SpelModel.view = view
            tekst = view.status
            modus = Modus.KIES_TROEF
            return wacht.await()
        }

        override suspend fun verder(view: SpelView, tekst: String) {
            if (snel) { snelStap(view); return }
            this@SpelModel.view = view
            this@SpelModel.tekst = tekst
            // De tellingen bewaren we na elke slag; het is een paar honderd bytes.
            bewaarplaats.schrijf(view.statistiek)
            if (instellingen.demo || automatisch) {
                // Vanzelf doorgaan: in demo kijkt niemand mee met een vinger.
                delay(if (view.spelUit) 2500 else 1200)
                return
            }
            val wacht = CompletableDeferred<Unit>()
            verderWacht = wacht
            modus = Modus.VERDER
            wacht.await()
        }
    }

    init {
        val v = bewaarplaats.leesVoorkeuren()
        if (v != null) {
            stijlZuid = v.stijlZuid; stijlNoord = v.stijlNoord; engels = v.engels
        } else {
            // Nog nooit gekozen: de taal volgt het apparaat.
            val talen = ConfigurationCompat.getLocales(app.resources.configuration)
            engels = Taal.engelsVoor((0 until talen.size()).map { talen[it]?.language ?: "" })
        }
        Taal.engels = engels
        zetInstellingen()
        start()
    }

    private fun start(metBewaard: Boolean = true) {
        job?.cancel()
        modus = Modus.GEEN
        tekst = ""
        val begin = if (metBewaard) bewaarplaats.lees() else null
        view = SpelView().also { if (begin != null) it.statistiek = begin }
        val spel = KjSpel(ui, leesInstellingen = { instellingen }, beginStatistiek = begin)
        // Op de hoofdthread: schrijven naar de Compose-toestand vanaf Dispatchers.Default
        // kwam op de emulator niet in het scherm aan. De engine rekent per zet in
        // milliseconden, dus dat is voor nu geen bezwaar.
        job = viewModelScope.launch { spel.loop() }
    }

    fun nieuwSpel() = start()

    /**
     * Eén slag bij snel spelen: het scherm en de bewaarplaats worden hooguit een paar keer per
     * seconde bijgewerkt, anders kost het tekenen meer dan het spelen zelf. Aan het eind van
     * elk spel geven we de hoofdthread even de ruimte.
     */
    private suspend fun snelStap(v: SpelView) {
        if (!v.spelUit) return
        val nu = System.nanoTime()
        if (nu - laatstGetekend > 250_000_000L) {
            laatstGetekend = nu
            view = v
            snelGespeeld = v.statistiek.spellen[0] + v.statistiek.spellen[1]
            bewaarplaats.schrijf(v.statistiek)
        }
        // Een miljoen spellen is genoeg: daarboven lopen in de Windows-versie de tellers over.
        if (v.statistiek.spellen[0] + v.statistiek.spellen[1] >= MAX_SPELLEN) {
            bewaarplaats.schrijf(v.statistiek)
            stopSnel()
            return
        }
        yield()
    }

    /** Snel spelen aan of uit. Aan: de computer speelt beide kanten, en er begint een nieuw spel. */
    fun zetSnel(aan: Boolean) {
        if (aan == snel) return
        if (aan) {
            demo = true
            zetInstellingen()
            snel = true
            snelGespeeld = view.statistiek.spellen[0] + view.statistiek.spellen[1]
            start()
        } else {
            stopSnel()
        }
    }

    /** Uit snel spelen komen: ook de demo gaat uit, zodat je weer zelf speelt. */
    private fun stopSnel() {
        snel = false
        demo = false
        zetInstellingen()
        start()
    }

    private fun zetInstellingen() {
        instellingen = Instellingen(
            demo = demo, openKaart = openKaart,
            zoektZuid = stijlZuid == 1, zoektNoord = stijlNoord == 1,
            claudeZuid = stijlZuid == 2, claudeNoord = stijlNoord == 2,
        )
    }

    private fun bewaarVoorkeuren() =
        bewaarplaats.schrijfVoorkeuren(Bewaarplaats.Voorkeuren(stijlZuid, stijlNoord, engels))

    /**
     * Demo wisselt de rol van Zuid van mens naar computer. Wacht het spel op dat moment al
     * op een kaart of troefkeuze van de mens, dan kan die vraag niet meer terug; daarom
     * begint er een nieuw spel (de tellingen blijven).
     */
    fun zetDemo(aan: Boolean) { demo = aan; zetInstellingen(); start() }
    fun zetOpenKaart(aan: Boolean) { openKaart = aan; zetInstellingen() }
    fun zetAutomatisch(aan: Boolean) { automatisch = aan; if (aan) gaVerder() }
    fun zetStijlNoord(stijl: Int) { stijlNoord = stijl; zetInstellingen(); bewaarVoorkeuren() }
    fun zetStijlZuid(stijl: Int) { stijlZuid = stijl; zetInstellingen(); bewaarVoorkeuren() }
    fun zetEngels(aan: Boolean) { engels = aan; Taal.engels = aan; bewaarVoorkeuren() }

    /** Alles op nul: de bewaarde tellingen weg en opnieuw beginnen. */
    fun wisStatistiek() {
        bewaarplaats.wis()
        start(metBewaard = false)
    }

    /** Een tik op een eigen kaart (hand of tafel). */
    fun klik(kaart: KaartView) {
        when (modus) {
            Modus.KIES_KAART -> {
                modus = Modus.GEEN
                kaartWacht?.complete(kaart.naam to kaart.kleur)
            }
            Modus.KIES_TROEF -> kiesTroef(kaart.kleur)   // een kaart aantikken kiest zijn kleur
            Modus.VERDER -> gaVerder()
            Modus.GEEN -> {}
        }
    }

    fun kiesTroef(kleur: Int) {
        if (modus != Modus.KIES_TROEF) return
        modus = Modus.GEEN
        troefWacht?.complete(kleur)
    }

    fun gaVerder() {
        if (modus != Modus.VERDER) return
        modus = Modus.GEEN
        verderWacht?.complete(Unit)
    }

    /** De zin voor de balk bovenin als er niets bijzonders te melden is. */
    val aansporing: String? get() = if (modus == Modus.VERDER && view.spelUit) Taal.tikVerder else null

    private companion object {
        const val MAX_SPELLEN = 1_000_000L
    }
}
